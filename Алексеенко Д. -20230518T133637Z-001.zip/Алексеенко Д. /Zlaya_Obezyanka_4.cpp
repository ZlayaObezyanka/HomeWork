﻿// Zlaya_Obezyanka_4.cpp : Этот файл содержит функцию "main". Здесь начинается и заканчивается выполнение программы.
//

#include <iostream>
#include <ctime>
int main()
{
	setlocale(LC_ALL, "Rus");
	srand (time(NULL));

	// Переменные разделены по заданиям.
	
	const int ROW = 10;
	const int COLS = 10;
	
	int arr[ROW][COLS] = {};
	int max = 0;
	int min = 0;

	int a = 0; // Динамическая переменная (пользователь вводит ее самостоятельно)
	

	int summ = 0; 
	
	int rex; //переменная для обозначения строк(столбцов) макс и мин суммы элементов 

	// '\'-- главная ди. '/' -- побочная ди.



	for (int i = 0; i < ROW; ++i) //рандом в массиве
	{
		for (int j = 0; j < COLS; ++j)
		{
			arr[i][j] = rand() % 100;
		}
	}
	

	for (int i = 0; i < ROW; ++i) //вывод массива, для сверения ответов 
	{

		for (int j = 0; j < COLS; ++j)
		{
			std::cout << arr[i][j] << "\t";
		}
		
		std::cout << std::endl;

	}
	
	
				std::cout << "_______________________________________";
				std::cout << std::endl;
				std::cout << std::endl;
	
	
	std::cout << "Часть массива, выше главной диагонали: \n";

	for (int i = 0; i < ROW; ++i)
	{
		for (int j = 0; j < COLS ; ++j)
		{
			if (j < COLS && j > i) 

				std::cout << arr[i][j] << "\t";

		}

		std::cout << std::endl;
		
	}
	


				std::cout << std::endl;
				std::cout << "_______________________________________";
				std::cout << std::endl;
				std::cout << std::endl;


	std::cout << "Часть массива, ниже главной диагонали: \n";

	for (int i = 0; i < ROW; ++i)
	{
		for (int j = 0; j < i; ++j) // от \ массив находится ниже, из-за этого j должна быть < i
		{
			if (i > j) // пока i > j, выводим 

				std::cout << arr[i][j] << "\t";

					
		}

		std::cout << std::endl;

	}
	
	
				std::cout << std::endl;
				std::cout << "_______________________________________";
				std::cout << std::endl;
				std::cout << std::endl;
	
	
	std::cout << "Часть массива, выше побочной диагонали: \n";
	
	for (int i = 0, x = 1; i < ROW; ++i, ++x)
	{
		for (int j = 0; j < COLS; ++j)
		{
			if (j < ROW - x)

				std::cout << arr[i][j] << "\t";


		}

		std::cout << std::endl;

		//не знаю, как объяснить текстом. По первой строке. ROW - Х (10 - 1), это ограничение для j, и так по нарастающей.
		
	}
	
	
	
				std::cout << std::endl;
				std::cout << "_______________________________________";
				std::cout << std::endl;
				std::cout << std::endl;


	std::cout << "Часть массива, ниже побочной диагонали: \n";

	for (int i = 0, x = 1; i < ROW; ++i, ++x)
	{
		for (int j = 0; j < COLS; ++j)
		{
			if (j > ROW - x)

				std::cout << arr[i][j] << "\t";


		}

		std::cout << std::endl;

		//аналогично прошлой задачи, но тут компелятор показывает значения после того, как j перейжет рубеж ROW - x 


	}
	
	
				std::cout << std::endl;
				std::cout << "_______________________________________";
				std::cout << std::endl;
				std::cout << std::endl;
		

	for (int i = 0; i < ROW; ++i)
	{


		
		for (int j = 0; j < COLS; ++j)
		{
			if (arr[j][i] > max)			// просто проверяет, фактическое значение больше имеющегося, или нет, и перезаписывает.

				max = arr[j][i];

		}


		std::cout << "Максимальное значение " << i+1 <<" столбца: " << max << "\t";
		
		
		max = 0;

		std::cout << std::endl;

	}
	
	
				std::cout << std::endl;
				std::cout << "_______________________________________";
				std::cout << std::endl;
				std::cout << std::endl;
		

	for (int i = 0; i < ROW; ++i)
	{
			min = 101; // максимум, в данной задаче, это 99, так как %100. как сделать иначе, я не знаю, но готов почитать информацию


		for (int j = 0; j < COLS; ++j)
		{
			if (arr[i][j] < min) // аналогично прошлой задачи, но в реверсе.

				min = arr[i][j];

		}


		std::cout << "Минимальное значение " << i + 1 << " строки: " << min << "\t";


	
		std::cout << std::endl;

	}


				std::cout << std::endl;
				std::cout << "_______________________________________";
				std::cout << std::endl;
				std::cout << std::endl;


	for (int i = 0; i < ROW; ++i)
	{
		int imin = i;

		int jmin = 0;

		min = 101;

		for (int j = 0; j < COLS; ++j)
		{
			if (arr[j][i] < min)

				min = arr[j][i];
			
		}
		//записывает в мин, после чего идет во второй фор (ниже), и проверяет, равно ли значение массива имеющимся данным. Если нет, то перезаписывает
		
		for (int j = 1; j <= COLS; ++j)
		{
			if (arr[j][i] == min)

				jmin = j + 1; //эт тоже перезаписывает, если вдруг что 

		}





		std::cout << "Координаты минимального значения " << i + 1 << " столбца: " << "{" << imin << ", " << jmin << "}" << "\t" << min << "\t";



		std::cout << std::endl;

	}


				std::cout << std::endl;
				std::cout << "_______________________________________";
				std::cout << std::endl;
				std::cout << std::endl;


	for (int i = 0; i < ROW; ++i)
	{
		int imax = i;

		int jmax = 0;

		max = 0;

		for (int j = 0; j < COLS; ++j)
		{
			if (arr[i][j] > max)

				max = arr[i][j];

		}


		for (int j = 1; j <= COLS; ++j)
		{
			if (arr[i][j] == max)

				jmax = j + 1;

		}

		//аналогично прошлой, но реверс



		std::cout << "Координаты максимального значения " << i + 1 << " столбца: " << "{" << imax << ", " << jmax << "}" << "\t" << max << "\t";



		std::cout << std::endl;

	}


				std::cout << std::endl;
				std::cout << "_______________________________________";
				std::cout << std::endl;
				std::cout << std::endl;


	for (int i = 0; i < ROW; ++i)
	{
		summ = 0;

		for (int j = 0; j < COLS; ++j)
		{
			if (arr[i][j] % 2 != 0 ) // не равен нулю, значит нечесть. Иди к остальным

				summ += arr[i][j];
			
		}
		
		
		std::cout << "Сумма нечетных элементов " << i +1 << " строки, равна: " << summ <<"\t";



		std::cout << std::endl;

	}


 				std::cout << std::endl;
				std::cout << "_______________________________________";
				std::cout << std::endl;
				std::cout << std::endl;


	for (int i = 0; i < ROW; ++i)
	{
		summ = 0;

		for (int j = 0; j < COLS; ++j)
		{
			if (arr[j][i] % 2 == 0) // равен 0? иди к остальным. Тоже нечесть, но нулёвка 

				summ += arr[j][i];

		}


		std::cout << "Сумма четных элементов " << i + 1 << " столбца, равна: " << summ << "\t";



		std::cout << std::endl;

	}


				std::cout << std::endl;
				std::cout << "_______________________________________";
				std::cout << std::endl;
				std::cout << std::endl;


	std::cout << "Введите число от 1 до 9 \t";
	std::cin >> a;
	do
	{
		
			if (a < 1 || a > 9)
			{
				std::cout << "Ну попросил же от 1 до 9. давай еще раз \t";
				std::cin >> a;
				continue;
			}

			break;

	} while (true);
	
			summ = 0;

	for (int i = 0; i < ROW; ++i)
	{


		for (int j = 0; j < COLS; ++j)
		{
			if (arr[j][i] % a == 0) // +- также, как и в прошлых задачах, но уже от значения, которое вводит человекоподобный

				summ += 1;

		}

	}
	std::cout << "Количество элементов кратных " << a << ", равна: " << summ;


				std::cout << std::endl;
				std::cout << "_______________________________________";
				std::cout << std::endl;
				std::cout << std::endl;


				rex = 0;
				max = 0;
	for (int j = 0, i; j < COLS; ++j)
	{
		
		summ = 0;



		for (i = 0; i < ROW; ++i)
		{

			summ += arr[j][i];
			
		}

		if (summ >= max)
		{

			max = summ;
			rex = j + 1;

		}
			

	}
	std::cout << std::endl;
	std::cout << "Номер строки с максимальным значением: " << rex << ". Значение: " << max << "\t";


	std::cout << std::endl;
	std::cout << "_______________________________________";
	std::cout << std::endl;
	std::cout << std::endl;


	rex = 0;
	min = 999;
	for (int i = 0, j; i < ROW; ++i)
	{

		summ = 0;



		for (j = 0; j < COLS; ++j)
		{

			summ += arr[i][j];

		}

		if (summ <= min)
		{

			min = summ;
			rex = j + 1;

		}







	}
	std::cout << std::endl;
	std::cout << "Номер столбца с минимальным значением: " << rex << ". Значение: " << min << "\t";



}

