﻿

#include <iostream>



int num(int a) // Функция переварачивает число. Было: 159; Стало: 951
{
    int m = 0;
   
   for(;a > 0;)
    {
        m = m * 10 + a % 10;
        a /= 10;
    }
       
   for (int i = 0; m > 0; ++i)
   {
       int size = 0; // Переменная, для записи цифр из введенного числа.
       size += m % 10;
       std::cout << size << std::endl;
       m = m / 10;

   }

    return m;
}


int noup(int a)
{
    int size_a = 0;
    for (;a > 0;)
    {
        size_a += a % 10;
        a = a / 10;
    }
    return size_a;
}



int main()
{
    setlocale(LC_ALL, "Rus");
    

    int meaning = 0;
    int function_num = 0;
    int function_noup = 0;
    int number = 0;

    std::cout << "Введите значение" << std::endl;
    std::cin >> meaning;

    number = meaning;

    function_noup = noup(meaning); //считает сумму чисел введенного числа.

    function_num = num(number);
    
    std::cout << "Сумма чисел вашего числа равно: " << function_noup << std::endl;
    
}

