﻿// Zlaya_Obezyanka_Game.cpp : Этот файл содержит функцию "main". Здесь начинается и заканчивается выполнение программы.
//

#include <iostream>
#include <ctime>
#include <windows.h>

char one()
{
    char indent = '\t';
    std::string one_main{
    " _________ \n" 
    "|         | \n" 
    "|    _    | \n" 
    "|   |_|   | \n" 
    "|         | \n" 
    "|_________| \n" 
    };

    std::cout << one_main;
    return indent;
} 

char two()
{
    char indent = '\t';
    std::string one_main{
    " _________ \n"
    "| _       | \n"
    "||_|      | \n"
    "|       _ | \n"
    "|      |_|| \n"
    "|_________| \n"
    };

    std::cout << one_main;
    return indent;
}

char three()
{
    char indent = '\t';
    std::string one_main{
    " _________ \n"
    "| _       | \n"
    "||_| _    | \n"
    "|   |_| _ | \n"
    "|      |_|| \n"
    "|_________| \n"
    };

    std::cout << one_main;
    return indent;
}

char four()
{
    char indent = '\t';
    std::string one_main{
    " ________ \n"
    "| _    _ | \n"
    "||_|  |_|| \n"
    "| _    _ | \n"
    "||_|  |_|| \n"
    "|________| \n"
    };

    std::cout << one_main;
    return indent;
}

char five()
{
    char indent = '\t';
    std::string one_main{
    " _________ \n"
    "| _     _ | \n"
    "||_| _ |_|| \n"
    "|   |_|   | \n"
    "||_|   |_|| \n"
    "|_________| \n"
    };

    std::cout << one_main;
    return indent;
}

char six()
{
    char indent = '\t';
    std::string one_main{
    " _________ \n"
    "| _     _ | \n"
    "||_|   |_|| \n"
    "||_|   |_|| \n"
    "||_|   |_|| \n"
    "|_________| \n"
    };
   
    std::cout << one_main;
    return indent;
}

int draft(int a, int b, int i)
{
    
    if (a == 1)
        std::cout << one() << std::endl;
    if (a == 2)
        std::cout << two() << std::endl;
    if (a == 3)
        std::cout << three() << std::endl;
    if (a == 4)
        std::cout << four() << std::endl;
    if (a == 5)
        std::cout << five() << std::endl;
    if (a == 6)
        std::cout << six() << std::endl;

    if (b == 1)
        std::cout << one() << std::endl;
    if (b == 2)
        std::cout << two() << std::endl;
    if (b == 3)
        std::cout << three() << std::endl;
    if (b == 4)
        std::cout << four() << std::endl;
    if (b == 5)
        std::cout << five() << std::endl;
    if (b == 6)
        std::cout << six() << std::endl;

    return ++i;

} // Показывает кубики, и работает как счетчик. Каждый игрок должен делать всего 4 броска.

int open_play()
{
    int dice[6] = { 1, 2, 3, 4, 5, 6 };
    int dice_value = 0;

    for (; dice_value == 0; )
        dice_value = dice[rand() % 6];

    return dice_value;
} //Рандом выпадения кубика.

void game1()
{
    int i = 0;

    int game_player_first;
    int game_player_second;
    int player_value = 0;
    int* pplayer_value = &player_value;

    int game_opponents_first;
    int game_opponents_second;
    int opponent_value = 0;
    int* popponent_value = &opponent_value;

    int dice[6] = { 1, 2, 3, 4, 5, 6 };
    int* pgame_player_first = &game_player_first;
    int* pgame_player_second = &game_player_second;
    int* pgame_opponents_first = &game_opponents_first;
    int* pgame_opponents_second = &game_opponents_second;

    std::cout << "Отлично, тогда сейчас поиграем" << std::endl;
    std::cout << "Кидай 1 кубик, и если выпадет больше 3, то я хожу первым, если же меньше 3, то я уступлю тебе серию первых бросков." << std::endl;
    Sleep(2000);
    std::cout << "Вы кидаете кубик:" << std::endl;
    Sleep(1500);
    game_player_first = open_play();

    std::cout << game_player_first << std::endl << std::endl;

    if (game_player_first > 3)
    {
        
        std::cout << "Ну чтож, начнем игру!" << std::endl;

        do
        {
            *pgame_player_first = open_play();
            *pgame_player_second = open_play();

            *pplayer_value += game_player_first;
            *pplayer_value += game_player_second;

            i = draft(game_player_first, game_player_second, i);
            std::cout << "У вас: \t" << player_value << std::endl;

            if (i < 5) {
                std::cout << "Кидай еще раз" << std::endl;
                Sleep(2000);
            }
            else
                break;

        } while (true);

        std::cout << "____________________" << std::endl;
        std::cout << "Отлично, теперь моя очередь!" << std::endl;
        i = 0;
        do
        {
            *pgame_opponents_first = open_play();
            *pgame_opponents_second = open_play();

            *popponent_value += game_opponents_first;
            *popponent_value += game_opponents_second;

            i = draft(game_opponents_first, game_opponents_second, i);

            std::cout << "У противника: \t" << opponent_value << std::endl;

            if (i < 5) {
                std::cout << "Кидаю еще раз" << std::endl;
                Sleep(1500);
            }
            else
                break;

        } while (true);
    }

    else if (game_player_first < 4)
    {
        do
        {
            *pgame_opponents_first = open_play();
            *pgame_opponents_second = open_play();

            *popponent_value += game_opponents_first;
            *popponent_value += game_opponents_second;

            i = draft(game_opponents_first, game_opponents_second, i);

            std::cout << "У противника: \t" << opponent_value << std::endl;

            if (i < 5) {
                std::cout << "Кидаю еще раз" << std::endl;
                Sleep(1500);
            }
            else
                break;

        } while (true);

        std::cout << "____________________" << std::endl;
        std::cout << "Теперь твоя очередь!" << std::endl;

        do
        {
            *pgame_player_first = open_play();
            *pgame_player_second = open_play();

            *pplayer_value += game_player_first;
            *pplayer_value += game_player_second;

            i = draft(game_player_first, game_player_second, i);
            std::cout << "У вас: \t" << player_value << std::endl;

            if (i < 5) {
                std::cout << "Кидай еще раз" << std::endl;
                Sleep(1500);
            }
            else
                break;

        } while (true);

    }

    if (opponent_value < player_value)
        std::cout << "Твоя победа, друг!" << std::endl;

    if (opponent_value > player_value)
        std::cout << "Тут моя взяла!" << std::endl;

    if (opponent_value == player_value)
        std::cout << "Победила дружба!" << std::endl;
}

// Тут 2 рандом person отвечает за рандом игрока (более расширенный). Gambler отвечает за рандом компьютера.
int person()
{
    srand(time(NULL));
    int arr_card[9] = { 2, 3, 4, 11, 6, 7, 8, 9, 10 };
    int num = 0;
    num = arr_card[rand() % 9];

    if (num == 2)
        std::cout << "Верный прислужник и оруженоситель. Ваш Валет. 2 очка" << "\n";
    if (num == 3)
        std::cout << "Хуже вина только дамы. Дама. 3 очка" << "\n";
    if (num == 4)
        std::cout << "Оп, а вот и Король. +4 очка" << "\n";
    if (num == 11)
        std::cout << "Изящный, в костюмчике. На поле выпал туз. 11 очков" << "\n";
    if (num == 6)
        std::cout << "Верный ли этот спутник, или он воткнет нож в спину? +6 очков" << "\n";
    if (num == 7)
        std::cout << "Верная сабля, способная рубить ваших врагов! +7 очков" << "\n";
    if (num == 8)
        std::cout << "Бесконечно можно смотреть на воду и огонь. +8 очков" << "\n";
    if (num == 9)
        std::cout << "Интересный факт: в Греции было 9 муз. А у нас +9 очков" << "\n";
    if (num == 10)
        std::cout << "Этот мир создан из нулей и единиц. А, стоп, не этот. +10 очков" << "\n";

    return num;
}

int gambler()
{
    srand(time(NULL));
    int arr_card[9] = { 10, 3, 4, 2, 6, 7, 8, 9, 11 };
    int num_gambler = 0;
    num_gambler = arr_card[rand() % 9];

    return num_gambler;
}

void game2()
{
    int person_card = 0;
    int gambler_card = 0;
    int num_card;
    int num_card_gambler;
    char door = '+';

    const int CARD = 11;
    int arr_card[9] = { 2, 3, 4, 11, 6, 7, 8, 9, 10 };

    do
    {
            std::cout << "Начнем игру. Где же мои картишки... \n";
            Sleep(1500);
            std::cout << "Ах, вот же они. \n";
            std::cout << std::endl;

            for (int i = 0; door == '+'; ++i)
            {
                num_card = person();
                person_card += num_card;

                std::cout << "\nУ вас на руках " << person_card << "\n";

                if (gambler_card >= 16)
                {
                    std::cout << "Пас" << std::endl;
                }

                if (gambler_card < 11)
                {
                    num_card_gambler = gambler();
                    gambler_card += num_card_gambler;
                    if (gambler_card <= 11)
                        std::cout << "У меня на руках " << gambler_card << "\n";
                }

                if (gambler_card > 11 && gambler_card < 17)
                {
                    num_card_gambler = gambler();
                    gambler_card += num_card_gambler;
                    std::cout << "Беру рубашкой вниз" << std::endl;
                }

                if (person_card == 21)
                {
                    std::cout << "У Вас максимальное количество очков. Больше только расход dualHorse\n"; 

                    for (; gambler_card <= 18;)
                    {
                        if (gambler_card <= 18)
                        {
                            num_card_gambler = 0;
                            num_card_gambler = gambler();
                            gambler_card += num_card_gambler;
                            std::cout << "Беру рубашкой вниз" << std::endl;
                        }
                    }
                    break;
                }

                if (person_card >= 21)
                {
                    std::cout << "Ну дружище, у тебя перебор. Ты проиграл. \n";
                    // зациклил ?                              
                    for (; gambler_card < 15;)
                    {
                        if (gambler_card <= 15)
                        {
                            num_card_gambler = 0;
                            num_card_gambler = gambler();
                            gambler_card += num_card_gambler;
                            std::cout << "Беру рубашкой вниз" << std::endl;
                        }
                    }
                    break;
                }

                door = ' ';

                std::cout << "Добавить карту? \t";
                std::cin >> door;
                if (door != '+' && door != '-')
                {
                    do
                    {
                        std::cout << "Я немного не понял, что ты хочешь от меня?\n";
                        std::cout << "Карту добавить, или нет?! \t";
                        std::cin >> door;


                    } while (door != '+' && door != '-');
                    {
                        continue;
                    }
                }
                if (door == '+')
                    continue;
                if (door == '-')
                {
                    for (; gambler_card < 15;)
                    {
                        if (gambler_card <= 15)
                        {
                            num_card_gambler = 0;
                            num_card_gambler = gambler();
                            gambler_card += num_card_gambler;
                            std::cout << "Беру рубашкой вниз" << std::endl;
                        }
                    }
                    break;
                }
            }

        
    } while (false);
    {
        if (21 >= person_card && person_card > gambler_card)
        {
            std::cout << "Ты победил! \n";

        }

        if (21 >= person_card && person_card < gambler_card && gambler_card > 21)
        {
            std::cout << "Ты победил! \n";
        }

        if (person_card < gambler_card && gambler_card <= 21)
        {
            std::cout << "Я победил. Еще одну партейку? \n";
        }

        if (person_card == gambler_card && gambler_card <= 21)
        {
            std::cout << "Ну тут победы нет ни у кого. Пойдем по пиву, или еще партейку? \n";
        }

        if (person_card > 21 && gambler_card > 21)
        {
            std::cout << "Ну, дружище, победы нет ни у кого." << std::endl;
        }
    }
       
}

int main()
{
    std::string name;
    int i = 0;
    int player = 0;
    int computer_player = 0;
    char open;
    
    setlocale(LC_ALL, "Rus");
    srand(time(NULL));
    

        std::cout << "Ничего себе ты соня." << std::endl;
        std::cout << "Тебя даже не разбудила ночная гроза." << std::endl;
        std::cout << "Кстати, скоро уже прибудем на место." << std::endl;
       
        Sleep(1500);

        std::cout << std::endl;
        std::cout << "Кстати говоря, не желаешь пообщаться с сокамерником?" << std::endl;
        std::cout << "Моё имя Рудольф, и я тут за убийство курицы." << std::endl;
        std::cout << "А как тебя звать?" << std::endl << std::endl;
    
        std::cout << "Введите ваше имя" << std::endl;
        std::cin >> name;
       
        if (name == "Kenny")
        {
            std::cout << "Только вы назвали своё имя, как вдруг корабль сел на мель, а от удара вы влетели в стелаж с дикими крысами." << std::endl;
            std::cout << "Врачи долго старались спасти вас, но вам потребовалась операция." << std::endl;
            std::cout << "К великому горю, у врачей, что были на карабле, был обед, и они пересадили вам картошку, вместо сердца" << std::endl;
           
            Sleep(3000);
            exit;
        }

        std::cout << "Слушай, дружище, хочешь поиграть, пока мы не добрались?" << std::endl;
        std::cout << "Введите +, для начала игры с Рудольфом, или -, для выхода" << std::endl;
        std::cin >> open;
        do
        {
            
            if (open == '+')
            {
                std::cout << "Кстати говоря, а во что ты хочешь сыграть? Выбор не велик, но всё же." << std::endl;


                for (; open == '+'; )
                {   
                    open = 0;
                    std::cout << "Выбирай:\n1. Кости \n2. Очко" << std::endl << std::endl;
                    std::cout << "Введите 1 или 2" << std::endl;
                    std::cin >> player;

                    if (player != 1 && player != 2)
                    {
                        std::cout << "Оказалось, что Рудольф очень обидчивый собеседник, и услышав от Вас не пойми что, он расстроился, и больше не хочет с вами разговаривать." << std::endl;
                        Sleep(1500);
                        exit;
                    }

                    if (player == 1)
                        game1();

                    if (player == 2)
                        game2();

                }

                std::cout << "Еще поиграем?" << std::endl;
                std::cout << "Введите +, для повторной игры, или -, для выхода." << std::endl;
                std::cin >> open;
            }

            else if (open == '-')
            {
                std::cout << "Вы отказались играть с вашим новоиспеченным товарищем, в надежде, что скоро уже прибудете на место." << std::endl;
                std::cout << "Увы, вам придется ждать еще очень долго" << std::endl;
                Sleep(1500);
                std::cout << "Очень" << std::endl;
                Sleep(1500);
                std::cout << "Долго" << std::endl;
                Sleep(1500);
                std::cout << "Ладно, я прикалываюсь, удачи в жизни" << std::endl;
                Sleep(1000);
                exit;
            }
        } while (true);

       

}

