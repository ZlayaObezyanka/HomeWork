﻿#include <iostream>
#include <cstring>
#include <string>
#include <conio.h>

std::string exam(char a, char b);
int calc(char a, char b); //символьный какулятор.
int calc(int a, int b); //int-овый какулятор.
double calc(double a, double b); // удвоенная точность 
//float calc(float a, float b); // Повышенная точность 
char simbol(); // ввод символа в переменную. Вынесен в функцию для защиты от пользователя.
int check();// Проверка правильности ввода чисел. Было сложно понять, но вроде смог. 
double checkW();

template<typename T, typename X>
T calc(T a, X b);
template<typename T>
T calc(T a, T b);

int main()
{
	setlocale(LC_ALL, "rus");

	char first_exe_char1, first_exe_char2;
	int second_exe_value1, second_exe_value2;
	double three_exe_value1, three_exe_value2;
	//float four_exe_value1, four_exe_value2;

	first_exe_char1 = simbol(); 
	std::cout << std::endl;
	first_exe_char2 = simbol();

	std::cout << std::endl << exam(first_exe_char1, first_exe_char2) << "\t" <<  std::endl;
	
	std::cout << calc(first_exe_char1, first_exe_char2) << "\t" << std::endl;

	second_exe_value1 = check();
	second_exe_value2 = check();
	std::cout << std::endl << calc(second_exe_value1, second_exe_value2) << std::endl;

	three_exe_value1 = checkW();
	three_exe_value2 = checkW();
	std::cout << calc(three_exe_value1, three_exe_value2) << std::endl;

	std::cout << calc(three_exe_value1, second_exe_value1) << std::endl;
}

char simbol()
{
	char simbol;
	std::cout << "Введите один любой символ в первую ячейку:" << std::endl;
	simbol = _getche();
	return simbol;
}

std::string exam(char a, char b)
{
	std::string str1;
	str1 += a;
	str1 += b;
	return str1;
}

int check()
{
	char value[64];
	char* pvalue = value;
	int trueValue = 0;
	bool open = true;

	do
	{
		std::cout << "Введите число:" << std::endl;
		std::cin >> value;

		while (*pvalue)
		{
			if (!isdigit(*pvalue++))
			{
				open = false;
				break;
			}

			if (open)
			{
				trueValue = atoi(value);
				break;
			}
			else
			{
				std::cout << "Вы ввели не числовое значение! Я верю, у Вас получится в следующий раз!" << std::endl;
				continue;
			}
		}
		break;
	} while (true);
	return trueValue;
} 
double checkW()
{
	char value[64];
	char* pvalue = value;
	double trueValue = 0.0;
	bool open = true;

	do
	{
		std::cout << "Введите число:" << std::endl;
		std::cin >> value;

		while (*pvalue)
		{
			if (!isdigit(*pvalue++))
			{
				open = false;
				break;
			}

			if (open)
			{
				trueValue = atof(value);
				break;
			}
			else
			{
				std::cout << "Вы ввели не числовое значение! Я верю, у Вас получится в следующий раз!" << std::endl;
				continue;
			}
		}
		break;
	} while (true);
	return trueValue;
}

int calc(char a, char b)
{
	char action = ' ';
	do {
		std::cout << "Введите одно из действий (+, -, /, *):" << std::endl;
		action = _getche();
		switch (action)
		{
		case '+':
			return a + b;

		case'-':
			return a - b;

		case '*':
			return a * b;

		case '/':
			return a / b;

		default:
			std::cout << "Твои пальцы слишком омэриканизированы! Ты ввел неверное! Попробуй еще раз" << std::endl;
			break;
		}
	} while (true);
}
int calc(int a, int b) 
{
	char action = ' ';
	do {
		std::cout << "Введите одно из действий (+, -, /, *):" << std::endl;
		action = _getche();
		switch (action)
		{
		case '+':
			return a + b;

		case'-':
			return a - b;

		case '*':
			return a * b;

		case '/':
			return a / b;

		default:
			std::cout << "Твои пальцы слишком омэриканизированы! Ты ввел неверное! Попробуй еще раз" << std::endl;
			break;
		}
	} while (true);
}
double calc(double a, double b)
{
	char action = ' ';
	do {
		std::cout << "Введите одно из действий (+, -, /, *):" << std::endl;
		action = _getche();
		switch (action)
		{
		case '+':
			return a + b;

		case'-':
			return a - b;

		case '*':
			return a * b;

		case '/':
			return a / b;

		default:
			std::cout << "Твои пальцы слишком омэриканизированы! Ты ввел неверное! Попробуй еще раз" << std::endl;
			break;
		}
	} while (true);
}
//float calc(float a, float b)
//{
//	char action = ' ';
//	do {
//		std::cout << "Введите одно из действий (+, -, /, *):" << std::endl;
//		action = _getche();
//		switch (action)
//		{
//		case '+':
//			return a + b;
//
//		case'-':
//			return a - b;
//
//		case '*':
//			return a * b;
//
//		case '/':
//			return a / b;
//
//		default:
//			std::cout << "Твои пальцы слишком омэриканизированы! Ты ввел неверное! Попробуй еще раз" << std::endl;
//			break;
//		}
//	} while (true);
//} // Не вижу смысла делать, так как дабл делает тоже самое, но с повышенной точностью, но принцип такой же.

template<typename T, typename X>
T calc(T a, X b)
{
	char action = ' ';
	do {
		std::cout << "Введите одно из действий (+, -, /, *):" << std::endl;
		action = _getche();
		switch (action)
		{
		case '+':
			return a + b;

		case'-':
			return a - b;

		case '*':
			return a * b;

		case '/':
			return a / b;

		default:
			std::cout << "Твои пальцы слишком омэриканизированы! Ты ввел неверное! Попробуй еще раз" << std::endl;
			break;
		}
	} while (true);
}


template<typename T>
T calc(T a, T b)
{
	char action = ' ';
	do {
		std::cout << "Введите одно из действий (+, -, /, *):" << std::endl;
		action = _getche();
		switch (action)
		{
		case '+':
			return a + b;

		case'-':
			return a - b;

		case '*':
			return a * b;

		case '/':
			return a / b;

		default:
			std::cout << "Твои пальцы слишком омэриканизированы! Ты ввел неверное! Попробуй еще раз" << std::endl;
			break;
		}
	} while (true);
}