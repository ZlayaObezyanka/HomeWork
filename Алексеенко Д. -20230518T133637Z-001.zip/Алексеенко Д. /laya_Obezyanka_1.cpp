// laya_Obezyanka_1.cpp : Этот файл содержит функцию "main". Здесь начинается и заканчивается выполнение программы.
//




#include <iostream>


/*

int main()
{
    setlocale(LC_ALL, "rus");
    

    double fValve;
    double sValve;
    double tValve;
    

    std::cout << "Введите сопротивление резистора R1 \n";
    std::cin >> fValve;

    std::cout << "Введите сопротивление резистора R2 \n";
    std::cin >> sValve;

    std::cout << "Введите сопротивление резистора R3 \n";
    std::cin >> tValve;     
    
    
    double foValve = 1 / fValve + 1 / sValve + 1 / tValve;
    std::cout << "Эквивалент сопротивлений равен \n" << 1 / foValve;

    return 0;
   
}




int main()
{
    setlocale(LC_ALL, "rus");

    double pi = 3.14159265;
    double D;
    //double tValve;


    std::cout << "Введите диаметр окружности в мм \n";
    std::cin >> D;

   
        double R = D / 2;
        double L = 2 * pi * R; 
        
        double S = pi * R * R;


        std::cout << "Длинна окружности в мм \n \t" << L << "Площадь окружности в мм \n \t " << S;





    return 0;



}


int main()
{
    setlocale(LC_ALL, "rus");

    double v;
    double v0;
    double t;

    std::cout << "Путник, твоя начальная скорость была? \n";
        std::cin >> v0;

    std::cout << "Путник, с какой скоростью ехала твоя телега? \n";
    std::cin >> v;

    std::cout << "Как долго ты летел с этой горы, странник? \n";
    std::cin >> t; 


             double  a0 = v - v0; 
             double a = a0 / t;

             double p = t * t;
             double p1 = a * p;
             double p2 = p1 / 2;


    double S = v0 * t + p2;

        std::cout << "Путник, наши святые говорят, что ты летел со скоростью \t" << S; 

            std::cout << "\t Так присядь же, выпий с нами";


        return 0;




}
*/


Синтаксически все грамотно оформлено, и в целом все отлично, молодец