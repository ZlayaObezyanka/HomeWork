﻿
#include <iostream>
#include <string>
#include <algorithm>

using std::cout;
using std::cin;
using std::endl; //Писать без std очень не привычно. Стринг уже решил не добавлять, потому что просто. 

void display(std::string a); 
void delete_for(std::string a); 
void add_to(std::string a);
void remove_end(std::string a);
void delete_string(std::string a);
void back(std::string a);
void transformation(char a);

int main()
{
    setlocale(LC_ALL, "rus");

    std::string inp_string;
    char user_char;
    
    std::cout << "Введите значение в строку" << std::endl;
    std::getline(cin, inp_string);
    display(inp_string);
    delete_for(inp_string);
    add_to(inp_string);
    remove_end(inp_string);
    delete_string(inp_string);
    transformation(user_char);
}


void display(std::string a)
{
    cout << a << endl;
}

void delete_for(std::string a)
{
    int index_of_erase, count_of_erase;
    cout << "Введите номер символа для удаления из строки" << endl;
    cin >> index_of_erase;
    cout << "Сколько символов вы хотите удалить?" << endl;
    cin >> count_of_erase;
    index_of_erase--;

    a.erase(index_of_erase, count_of_erase);
    display(a);
}

void add_to(std::string a)
{
    std::string add_string;
    cout << "Что вы хотите добавить в конец строки?" << endl;
    cin >> add_string;
    a.append(add_string);
    display(a);
}

void remove_end(std::string a)
{
    int count_of_erase;
    cout << "Сколько элементов вы хотите удалить с конца строки?" << endl;
    cin >> count_of_erase;

    for (int i = 0; i < count_of_erase; i++)
        a.pop_back();
    display(a);
}




void delete_string(std::string a)
{
    char user_choice;

        do
    {
        cout << "Хотите удалить строку?(y/n)" << endl;
        cin >> user_choice;
        switch (user_choice)
        {
        case 'y':
            a.clear();
            cout << "Ваша строка пуста, тут было гы гы гы, но не гы гы гы!" << endl;
            continue;
        case 'n':
            display(a);
            continue;
        default:
            cout << "Введите корректное значение" << endl;
            break;
        }
    } while (false);
    
}

void back(std::string a)
{
    std::reverse(a.begin(), a.end());
    display(a);
}

void transformation() 
{
    do
    {
            std::string a;
            char x[10] = {};
            std::cout << "Введите не более 10 символов в с-строку" << std::endl;
            std::cin >> x;
            if (x[10] <= 10)
            {
                std::cout << x << std::endl;

                a = std::string(x);
                std::cout << a << std::endl;
                break;
            }
            else
            {
                std::cout << "Ну ты что, глупенький? 10 символов, это чуть больше 9, но чуть меньше 11.";
                continue;
            }
    }
    while (true);
}
