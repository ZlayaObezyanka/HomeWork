﻿// Zlaya_Obezyanka 2.cpp : Этот файл содержит функцию "main". Здесь начинается и заканчивается выполнение программы.
//

#include <iostream>
/*
int main()
{
	
	setlocale(LC_ALL, "rus");



	int first_Value;
	int second_Value;
	int sum = 0;

	std::cout << "Введите первое значение \n ";
	std::cin >> first_Value;

	std::cout << "Введите второе значение \n ";
	std::cin >> second_Value;
   
	if (first_Value < second_Value)
	{

		do
		{
			if (first_Value % 2 != 0)
			{

				sum += first_Value;

			}
			++first_Value;


		} while (first_Value < second_Value);
		
		
		std::cout << "Сумма нечетных чисел равно: \n" << sum ;
	}
	


	else if (first_Value >= second_Value)
	{

		std::cout << "Идем от меньшего к большему! Попробуйте в другой раз.";

	}
	return 0;
//Имеется вопрос. Скриншот с прошлым кодом остался. Пытался сделать через for, но не вышло
//Скрин скину. Сможете рассказать про ошибку? 

	
}*/

/*
int main()
{

	setlocale(LC_ALL, "rus");


	int side;
				//int base; -- Оказалось ненужным 

	char br = '^';
	char bur = ' ';


	std::cout << "Введите сторону равнобедренного треугольника \n \n";
	std::cin >> side;
	
			//std::cout << "Введите основание равнобедренного треугольника \n "; -- оказалось ненужным 
			//std::cin >> base; -- оказалось ненужным


	for (int i = 1, n = 1; i < side; ++n)
	{
		

		for (i = side ; i > n; --i)
		{
			putchar(bur);
	
		}
		
		for (int i = 1; i < n * 2; ++i)
		
			putchar(br);
		putchar('\n');
		
		

	}

	

	for (int i = 1, f = 1; f < side ; ++f)
	{
				
		for (i = 1 ; i <= f ; ++i )
		{
			putchar(bur);

		}


		for (int i = 2 * side ; i - 1 > f * 2; --i)

			putchar(br);
		putchar('\n');


	

	}
	return 0;
	}
	
	
	*/


/*
 
 //это моя подсказка. Оставил для себя, на будущее.
 
#define SIZE 10

int main()
 {
	size_t i, j;

	for (i = 0; i <= SIZE; ++i)
	{
		for (j = SIZE; j > i; --j)
			putchar(' ');
		for (j = 0; j < 2 * i; ++j)
			putchar('*');
		putchar('\n');
	}


}*/

/*
int main()
{

	setlocale(LC_ALL, "rus");


	int num;
	int value = 1;

	std::cout << "Введите число \t ";
	std::cin >> num;

	for (int i = 1; i <= num; ++i)
	{
		value = value * i;
	}

	std::cout << value;

	return 0;
} */






/*
int main()
{

	setlocale(LC_ALL, "rus");




	
	char door = '0';

	
	do
	{
		

		do
		{
			int a = 1;
			int b = 2;
			int num;
			int value = 1;
			int i = 1;
			std::cout << "Введите число \t";
			std::cin >> num;


			for (int i = 1; i <= num; i++)
			{

				value = value * i;

			}

			std::cout << "Факториал числа " << num << " равен " << value << std::endl;

			std::cout << "ВЫйти? Y/N \t";
			std::cin >> door;

			if (door == 121)
			{
				a > b;

			}

		}



		while (door == 121);
		

	}
		



		while (false);

		return 0;

	

}


*/