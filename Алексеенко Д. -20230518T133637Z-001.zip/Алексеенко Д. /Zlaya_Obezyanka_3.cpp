﻿
#include <iostream>


/*

	// Задача #2
int main()
{
	setlocale(LC_ALL, "rus");



	const int size = 5;
	int arr[size] = {};


	std::cout << "Введите число с учетом знака" << std::endl;
	for (int i = 0; i < size; i++) // цикл вводит значения в массив.
	{
		std::cout << i+1 << '-' << "значение равно: \t ";
		std::cin >> arr[i];

	}

	int result = 1;

	for (int i = 0; i < size; i++) // Цикл находит произведение нечетных значений массива.
	{

		if (arr[i] %2 !=0 )

			result *= arr[i];



	}

	std::cout << "Произведение нечетных значений равно \t" << result;



	std::cout << std::endl;

	result = 1; // переприсваивает переменной значение =1. В противном случае переменная останется равна значению из прошлого цикла.


	for (int i = 0; i < size; i++) // Цикл находит произведение четных значений массива.
	{


		if (arr[i] % 2 == 0)

			result *= arr[i];


	}

	std::cout << "Произведение четных значений равно \t" << result;

	return 0;

}
*/



//___________________________________________________________________________

/*

		//задание #1
int main()
{
	setlocale(LC_ALL, "rus");

	const int size = 10;
	int arr[size] = {};

	int result = 0;

	std::cout << "Введите число с учетом знака" << std::endl; // Вынес из цикла, для эстетики

	for (int i = 0; i < size; i++)
	{

		std::cout << i+1 << '-' << "значение равно: \t ";

		std::cin >> arr[i];

	}




	for (int i = 0; i < size; i++)
	{

		if (arr[i] % 2 != 0 && arr[i] > 0 ) // условие arr[i] > 0 позволяет нам убрать все отрицательные числа.
		{
			result += arr[i];

		}


	}
	std::cout << "Сумма всех нечетных положительных чисел равна \t" << result;
	std::cout << std::endl;



	result = 0;
	for (int i = 0; i < size; i++)
	{

		if (arr[i] % 2 != 0 && arr[i] < 0) // условие arr[i] < 0 позволяет нам убрать все положительные числа.
		{
			result += arr[i];

		}


	}
	std::cout << "Сумма всех нечетных отрицательных чисел равна \t" << result;
	std::cout << std::endl;


	result = 0;
	for (int i = 0; i < size; i++)
	{

		if (arr[i] % 2 == 0 && arr[i] < 0)
		{
			result += arr[i];

		}


	}
	std::cout << "Сумма всех четных отрицательных чисел равна \t" << result;
	std::cout << std::endl;


	result = 0;
	for (int i = 0; i < size; i++)
	{

		if (arr[i] % 2 == 0 && arr[i] > 0)
		{
			result += arr[i];

		}


	}
	std::cout << "Сумма всех четных положительных чисел равна \t" << result;
	std::cout << std::endl;


	return 0;



}
*/

//____________________________________________________


int main()
{
	setlocale(LC_ALL, "rus");

	const int size = 10;
	int arr[size] = {};
	int max = 0;

	std::cout << "Введите значения: ";
	std::cout << std::endl;

	for (int i = 0; i < size; i++)
	{
		std::cout << i + 1 << '-' << "значение равно: \t ";
		std::cin >> arr[i];
	}


	for (int i = 0; i < size; i++) // В этом цикле прогоняется весь массив, и в переменную max присваивается наибольшее число, из него
	{

		if (arr[i] > max)
		{
			max = arr[i];
		}


	}
	std::cout << max;

	return 0;

}
